document.getElementById('btn-calcular').addEventListener('click', function() {
    // 1. Captura de elementos
    const nombre = document.getElementById('nombre').value.trim();
    const cargo = document.getElementById('cargo').value.trim();
    const rows = document.querySelectorAll('.criterio-row');
    const errorContainer = document.getElementById('error-container');
    const resultArea = document.getElementById('result-area');

    let errores = [];
    let sumaPesos = 0;
    let notaFinal = 0;

    // 2. Validaciones básicas de nombre y cargo [cite: 28]
    if (!nombre) errores.push("El nombre del colaborador es obligatorio.");
    if (!cargo) errores.push("El cargo del colaborador es obligatorio.");

    // 3. Procesamiento de filas de criterios
    rows.forEach((row, index) => {
        const puntaje = parseFloat(row.querySelector('.crit-score').value);
        const peso = parseFloat(row.querySelector('.crit-weight').value);
        const n = index + 1;

        // Validar puntaje (1-10) [cite: 29]
        if (isNaN(puntaje) || puntaje < 1 || puntaje > 10) {
            errores.push(`El puntaje del criterio ${n} debe estar entre 1 y 10.`);
        }

        // Validar peso (0-100) [cite: 30]
        if (isNaN(peso) || peso < 0 || peso > 100) {
            errores.push(`El peso del criterio ${n} debe estar entre 0 y 100.`);
        } else {
            sumaPesos += peso;
        }

        // Cálculo acumulativo de la nota [cite: 35]
        if (!isNaN(puntaje) && !isNaN(peso)) {
            notaFinal += (puntaje * peso) / 100;
        }
    });

    // 4. Validar suma de pesos (exactamente 100) [cite: 31]
    if (sumaPesos !== 100) {
        errores.push(`Los pesos deben sumar 100% (actual: ${sumaPesos}%).`);
    }

    // 5. Mostrar errores o resultados [cite: 32]
    if (errores.length > 0) {
        errorContainer.innerHTML = "<strong>Corrige los siguientes errores:</strong><ul>" + 
            errores.map(e => `<li>${e}</li>`).join('') + "</ul>";
        errorContainer.style.display = 'block';
        resultArea.style.display = 'none';
    } else {
        errorContainer.style.display = 'none';
        mostrarResultado(nombre, notaFinal, resultArea);
    }
});

// Función propia para encapsular la lógica de salida [cite: 48]
function obtenerCategoria(nota) {
    if (nota >= 9.0) return { texto: 'Excelente', clase: 'cat-excelente' };
    if (nota >= 7.0) return { texto: 'Bueno', clase: 'cat-bueno' };
    if (nota >= 5.0) return { texto: 'Regular', clase: 'cat-regular' };
    return { texto: 'Insuficiente', clase: 'cat-insuficiente' };
}

function mostrarResultado(nombre, nota, area) {
    const info = obtenerCategoria(nota);
    area.className = `result-box ${info.clase}`; // Aplicar color según categoría [cite: 42]
    area.innerHTML = `
        <h3>Resultado de la Evaluación</h3>
        <p><strong>Colaborador:</strong> ${nombre}</p>
        <p><strong>Nota Final:</strong> ${nota.toFixed(2)}</p>
        <p><strong>Categoría:</strong> ${info.texto}</p>
    `;
    area.style.display = 'block';
}